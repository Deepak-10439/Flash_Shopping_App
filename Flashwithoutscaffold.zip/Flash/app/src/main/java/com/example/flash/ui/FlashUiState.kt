package com.example.flash.ui

data class FlashUiState (
    val clickStatus: String = "Hello ViewModels",
    val selectedCategory: Int =0
)